import grails.converters.*


class ContactController {

    def index = {
		
	}
	
	
}
