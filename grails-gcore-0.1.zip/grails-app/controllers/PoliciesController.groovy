import grails.converters.*


class PoliciesController {

    def dataAccess = {
		
	}
	
	def publication = {
		
	}
	
	def deniedAccess = {
		
	}
	
	def licenses = {
		
	}
	
	
}
