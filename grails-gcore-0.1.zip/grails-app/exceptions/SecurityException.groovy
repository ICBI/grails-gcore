import java.lang.Exception

class SecurityException extends Exception{
	SecurityException(String msg) {
	    super(msg)
	  }
	
}