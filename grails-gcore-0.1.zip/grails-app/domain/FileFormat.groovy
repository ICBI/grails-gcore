class FileFormat{
	static mapping = {
		table 'COMMON.FILE_FORMAT'
		version false
		id column:'FILE_FORMAT_ID'
	}
	
	static searchable = true
	
	String name
	String definition
	
	
	
	
}