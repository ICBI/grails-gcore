class MSDesign {
	static mapping = {
		table 'COMMON.MS_DESIGN'
		version false
		id column:'MS_DESIGN_ID'
	}
	
	String msType
	String polarity
}
