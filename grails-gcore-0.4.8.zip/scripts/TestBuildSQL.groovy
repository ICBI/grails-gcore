import org.codehaus.groovy.grails.commons.ConfigurationHolder as CH
import org.springframework.orm.hibernate3.SessionFactoryUtils
import org.springframework.orm.hibernate3.SessionHolder
import org.springframework.transaction.support.TransactionSynchronizationManager


grailsHome = Ant.antProject.properties."env.GRAILS_HOME"
includeTargets << grailsScript("Bootstrap")
includeTargets << grailsScript("Init")

target(main: "run script to append sql statements") {
	depends(clean, compile, classpath)
	
	// Load up grails contexts to be able to use GORM
	loadApp()
	configureApp()
	
	
	def targetFile = new File("/Users/kmr75/Downloads/testvariants.csv")
	File file = new File("/Users/kmr75/Downloads/testvariants.sql")
	def targetMap = [:]
	println "looking up variants..."
	targetFile.eachLine{line, number ->
		if(number != 1) {
			def data = line.split('\t')
			file << "INSERT INTO kmr75.variants (variant_id, chromosome, begin_position,end_position,var_type,reference_code,allele_seq,xref,HG00732110036ASM,HG00731110036ASM,HG00733110036ASM) VALUES ("+data[0]+", '"+data[1]+"',"+data[2]+","+data[3]+",'"+data[4]+"','"+data[5]+"','"+data[6]+"','"+data[7]+"','"+data[8]+"','"+data[9]+"','"+data[10]+"');\n"
		}
	}
	
	
}


setDefaultTarget(main)
