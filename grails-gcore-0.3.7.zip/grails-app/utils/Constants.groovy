class Constants{
	def static final USER_LIST = "USER_LIST"
	def static final SAVED_ANALYSIS = "SAVED_ANALYSIS"
	def static final TEMPORARY = "_temporary"
	def static final PATIENT_LIST = "patient"
	def static final GENE_LIST = "gene"
	def static final REPORTER_LIST = "reporter"
	def static final SUBJECT_LIST = "clinical"
	def static final BIOSPECIMEN = 'BIOSPECIMEN'
}