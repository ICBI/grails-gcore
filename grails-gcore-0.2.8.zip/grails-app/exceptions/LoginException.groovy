import java.lang.Exception

class LoginException extends Exception{
	LoginException(String msg) {
	    super(msg)
	  }
	
}