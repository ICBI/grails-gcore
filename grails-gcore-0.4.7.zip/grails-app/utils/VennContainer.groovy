import grails.converters.*

class VennContainer{
	
	Map dictionary
	Object vennData
	Object graphData
	
	
}