DROP USER ${projectName} cascade;
